#!/bin/bash

# ============================================================================
# Claude Code Web Terminal - Uninstall
# ============================================================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

USER_NAME="${SUDO_USER:-$USER}"
USER_HOME=$(eval echo "~$USER_NAME")

if [[ $EUID -ne 0 ]]; then
    echo "Run with sudo: sudo ./uninstall.sh"
    exit 1
fi

echo ""
echo "This will remove Claude Code Web Terminal."
read -p "Continue? [y/N] " -n 1 -r
echo ""

if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Aborted."
    exit 0
fi

echo ""

# Stop and disable service
echo "[*] Stopping service..."
systemctl stop claude-terminal 2>/dev/null
systemctl disable claude-terminal 2>/dev/null

# Stop healthcheck timer
echo "[*] Stopping healthcheck timer..."
systemctl stop claude-terminal-healthcheck.timer 2>/dev/null
systemctl disable claude-terminal-healthcheck.timer 2>/dev/null

# Remove systemd units
echo "[*] Removing systemd units..."
rm -f /etc/systemd/system/claude-terminal.service
rm -f /etc/systemd/system/claude-terminal-healthcheck.service
rm -f /etc/systemd/system/claude-terminal-healthcheck.timer
systemctl daemon-reload

# Remove custom frontend
echo "[*] Removing custom ttyd frontend..."
rm -rf /usr/local/share/claude-terminal

# Remove scripts
echo "[*] Removing scripts..."
rm -f /usr/local/bin/claude-terminal-start
rm -f /usr/local/bin/claude-terminal-stop
rm -f /usr/local/bin/claude-terminal-status
rm -f /usr/local/bin/claude-terminal-healthcheck
rm -f /usr/local/bin/claude-launcher
rm -f /usr/local/bin/clp
rm -f /usr/local/share/clp-completion.bash
rm -f "$USER_HOME/bin/claude-terminal-init"

# Remove sudoers
echo "[*] Removing sudoers config..."
rm -f /etc/sudoers.d/claude-terminal

# Remove Tailscale serve
echo "[*] Removing Tailscale serve..."
tailscale serve off 2>/dev/null

# Clean up bashrc
echo "[*] Cleaning ~/.bashrc..."
sed -i '/# === Claude Code Web Terminal ===/,/# === End Claude Code ===/d' "$USER_HOME/.bashrc" 2>/dev/null

echo ""
read -p "Remove tmux config (~/.tmux.conf)? [y/N] " -n 1 -r
echo ""
if [[ $REPLY =~ ^[Yy]$ ]]; then
    rm -f "$USER_HOME/.tmux.conf"
    echo -e "${GREEN}[✓]${NC} tmux config removed"
fi

# Kill tmux session
echo ""
read -p "Kill active tmux 'claude' session? [y/N] " -n 1 -r
echo ""
if [[ $REPLY =~ ^[Yy]$ ]]; then
    tmux kill-session -t claude 2>/dev/null
    echo -e "${GREEN}[✓]${NC} tmux session killed"
fi

echo ""
echo -e "${GREEN}[✓]${NC} Uninstall complete!"
echo ""
echo -e "${YELLOW}Note:${NC} ttyd, tmux, and Tailscale were NOT removed."
echo "To remove them:"
echo "  sudo apt remove ttyd"
echo "  sudo apt remove tmux"
echo "  sudo apt remove tailscale"
echo ""
