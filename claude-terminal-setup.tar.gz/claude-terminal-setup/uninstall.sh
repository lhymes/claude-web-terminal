#!/bin/bash

# ============================================================================
# Claude Code Web Terminal - Uninstall
# ============================================================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

USER_NAME="${SUDO_USER:-$USER}"
USER_HOME=$(eval echo "~$USER_NAME")

if [[ $EUID -ne 0 ]]; then
    echo "Run with sudo: sudo ./uninstall.sh"
    exit 1
fi

echo ""
echo "This will remove Claude Code Web Terminal."
read -p "Continue? [y/N] " -n 1 -r
echo ""

if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Aborted."
    exit 0
fi

echo ""

# Stop and disable service
echo "[*] Stopping service..."
systemctl stop claude-terminal 2>/dev/null
systemctl disable claude-terminal 2>/dev/null

# Remove systemd service
echo "[*] Removing systemd service..."
rm -f /etc/systemd/system/claude-terminal.service
systemctl daemon-reload

# Remove scripts
echo "[*] Removing scripts..."
rm -f /usr/local/bin/claude-terminal-start
rm -f /usr/local/bin/claude-terminal-stop
rm -f /usr/local/bin/claude-terminal-status
rm -f /usr/local/bin/claude-launcher
rm -f /usr/local/bin/clp
rm -f /usr/local/share/clp-completion.bash
rm -f "$USER_HOME/bin/claude-terminal-init"

# Remove sudoers
echo "[*] Removing sudoers config..."
rm -f /etc/sudoers.d/claude-terminal

# Remove Tailscale serve
echo "[*] Removing Tailscale serve..."
tailscale serve off 2>/dev/null

# Clean up bashrc
echo "[*] Cleaning ~/.bashrc..."
sed -i '/# === Claude Code Web Terminal ===/,/# === End Claude Code ===/d' "$USER_HOME/.bashrc" 2>/dev/null

echo ""
read -p "Remove Zellij config (~/.config/zellij)? [y/N] " -n 1 -r
echo ""
if [[ $REPLY =~ ^[Yy]$ ]]; then
    rm -rf "$USER_HOME/.config/zellij"
    echo -e "${GREEN}[✓]${NC} Zellij config removed"
fi

echo ""
read -p "Remove Zellij binary? [y/N] " -n 1 -r
echo ""
if [[ $REPLY =~ ^[Yy]$ ]]; then
    rm -f /usr/local/bin/zellij
    echo -e "${GREEN}[✓]${NC} Zellij removed"
fi

echo ""
echo -e "${GREEN}[✓]${NC} Uninstall complete!"
echo ""
echo -e "${YELLOW}Note:${NC} ttyd and Tailscale were NOT removed."
echo "To remove them:"
echo "  sudo apt remove ttyd"
echo "  sudo apt remove tailscale"
echo ""
