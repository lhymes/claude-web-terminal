#!/bin/bash
set -e

# ============================================================================
# Claude Code Web Terminal - Installation Script
# ============================================================================
# A mobile-friendly, persistent web terminal for Claude Code sessions
# Access from any browser — phone, tablet, or laptop
#
# Requirements:
#   - Ubuntu WSL (20.04, 22.04, or 24.04)
#   - Tailscale account (free at https://tailscale.com)
#   - sudo access
#
# Usage: sudo ./install.sh
# ============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
USER_NAME="${SUDO_USER:-$USER}"
USER_HOME=$(eval echo "~$USER_NAME")

# ============================================================================
# Configuration - Customize these if needed
# ============================================================================
ZELLIJ_SESSION_NAME="claude"
TTYD_PORT="7681"
PROJECTS_DIR="projects"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status() { echo -e "${BLUE}[*]${NC} $1"; }
print_success() { echo -e "${GREEN}[✓]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[!]${NC} $1"; }
print_error() { echo -e "${RED}[✗]${NC} $1"; }

# ============================================================================
# Preflight Checks
# ============================================================================

print_status "Running preflight checks..."

if [[ $EUID -ne 0 ]]; then
    print_error "This script must be run with sudo"
    echo "Usage: sudo ./install.sh"
    exit 1
fi

if [ -z "$USER_NAME" ] || [ "$USER_NAME" = "root" ]; then
    print_error "Please run with sudo, not as root directly"
    echo "Usage: sudo ./install.sh"
    exit 1
fi

if ! grep -qi microsoft /proc/version 2>/dev/null; then
    print_warning "This doesn't appear to be WSL. Continuing anyway..."
fi

echo ""
echo "Installing for user: $USER_NAME"
echo "Home directory: $USER_HOME"
echo ""

# ============================================================================
# Install Dependencies
# ============================================================================

print_status "Updating package lists..."
apt-get update -qq

print_status "Installing ttyd..."
apt-get install -y -qq ttyd

print_status "Installing Zellij..."
ZELLIJ_VERSION=$(curl -s https://api.github.com/repos/zellij-org/zellij/releases/latest | grep '"tag_name"' | sed -E 's/.*"([^"]+)".*/\1/')
if [[ -z "$ZELLIJ_VERSION" ]]; then
    ZELLIJ_VERSION="v0.43.1"
fi
curl -sL "https://github.com/zellij-org/zellij/releases/download/${ZELLIJ_VERSION}/zellij-x86_64-unknown-linux-musl.tar.gz" | tar xz -C /usr/local/bin
chmod +x /usr/local/bin/zellij
print_success "Zellij installed: $(zellij --version)"

# ============================================================================
# Install/Check Tailscale
# ============================================================================

if ! command -v tailscale &> /dev/null; then
    print_status "Installing Tailscale..."
    curl -fsSL https://tailscale.com/install.sh | sh
    print_warning "Tailscale installed. Run 'sudo tailscale up' to authenticate."
else
    print_success "Tailscale already installed"
fi

# ============================================================================
# Create Zellij Configuration
# ============================================================================

print_status "Creating Zellij configuration..."

ZELLIJ_CONFIG_DIR="$USER_HOME/.config/zellij"
mkdir -p "$ZELLIJ_CONFIG_DIR/layouts"

cat > "$ZELLIJ_CONFIG_DIR/config.kdl" << 'ZELLIJ_CONFIG'
// Claude Code Web Terminal - Zellij Configuration
// Optimized for mobile/touch interaction

default_layout "claude"
default_shell "bash"

mouse_mode true
scroll_buffer_size 50000
copy_on_select true

simplified_ui true
pane_frames false

session_serialization true
serialize_pane_viewport true

on_force_close "quit"

keybinds {
    shared {
        bind "Alt 1" { GoToTab 1; }
        bind "Alt 2" { GoToTab 2; }
        bind "Alt 3" { GoToTab 3; }
        bind "Alt 4" { GoToTab 4; }
        bind "Alt 5" { GoToTab 5; }
        bind "Alt 6" { GoToTab 6; }
        bind "Alt 7" { GoToTab 7; }
        bind "Alt 8" { GoToTab 8; }
        bind "Alt 9" { GoToTab 9; }
    }
}

themes {
    claude {
        fg "#d4d4d4"
        bg "#1e1e1e"
        black "#000000"
        red "#f44747"
        green "#6a9955"
        yellow "#dcdcaa"
        blue "#569cd6"
        magenta "#c586c0"
        cyan "#4ec9b0"
        white "#ffffff"
        orange "#ce9178"
    }
}
theme "claude"

ui {
    pane_frames {
        hide_session_name true
    }
}
ZELLIJ_CONFIG

# Layout with launcher tab
cat > "$ZELLIJ_CONFIG_DIR/layouts/claude.kdl" << 'ZELLIJ_LAYOUT'
layout {
    default_tab_template {
        children
        pane size=1 borderless=true {
            plugin location="compact-bar"
        }
    }
    
    tab name="launcher" focus=true {
        pane
    }
}
ZELLIJ_LAYOUT

chown -R "$USER_NAME:$USER_NAME" "$ZELLIJ_CONFIG_DIR"
print_success "Zellij configuration created"

# ============================================================================
# Create bin directory
# ============================================================================

mkdir -p "$USER_HOME/bin"
chown "$USER_NAME:$USER_NAME" "$USER_HOME/bin"

# ============================================================================
# Create Systemd Service
# ============================================================================

print_status "Creating systemd service..."

cat > /etc/systemd/system/claude-terminal.service << SYSTEMD_SERVICE
[Unit]
Description=Claude Code Web Terminal (ttyd + zellij)
After=network.target

[Service]
Type=simple
User=$USER_NAME
Environment="HOME=$USER_HOME"
Environment="TERM=xterm-256color"
WorkingDirectory=$USER_HOME

ExecStart=/usr/bin/ttyd --writable --port $TTYD_PORT /usr/local/bin/zellij attach $ZELLIJ_SESSION_NAME --create

Restart=always
RestartSec=5

NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=read-only
ReadWritePaths=$USER_HOME
ReadWritePaths=/tmp
PrivateTmp=false

[Install]
WantedBy=multi-user.target
SYSTEMD_SERVICE

systemctl daemon-reload
systemctl enable claude-terminal
print_success "Systemd service created"

# ============================================================================
# Create Helper Scripts
# ============================================================================

print_status "Creating helper scripts..."

# Init script for clean startup
cat > "$USER_HOME/bin/claude-terminal-init" << 'INIT_SCRIPT'
#!/bin/bash
# Clean up stale sessions and start fresh

# Kill orphan ttyd processes (not from systemd)
for pid in $(pgrep -f "ttyd.*7681" 2>/dev/null); do
    if ! systemctl show claude-terminal --property=MainPID 2>/dev/null | grep -q "MainPID=$pid"; then
        sudo kill $pid 2>/dev/null
    fi
done

# Delete stale zellij sessions
zellij delete-session claude 2>/dev/null

# Restart the service
sudo systemctl restart claude-terminal

echo "Claude terminal ready at http://localhost:7681"
INIT_SCRIPT

# Start script
cat > /usr/local/bin/claude-terminal-start << 'START_SCRIPT'
#!/bin/bash
echo "Starting Claude Code Web Terminal..."
sudo systemctl start claude-terminal
sleep 2
if systemctl is-active --quiet claude-terminal; then
    echo "✓ Terminal running at http://localhost:7681"
    
    if command -v tailscale &> /dev/null; then
        TS_IP=$(tailscale ip -4 2>/dev/null)
        TS_HOSTNAME=$(tailscale status --json 2>/dev/null | grep -o '"Self":{[^}]*"DNSName":"[^"]*"' | grep -o '"DNSName":"[^"]*"' | cut -d'"' -f4 | sed 's/\.$//')
        if [[ -n "$TS_HOSTNAME" ]]; then
            echo "✓ Remote access: https://${TS_HOSTNAME}"
        fi
    fi
else
    echo "✗ Failed to start. Run: sudo journalctl -u claude-terminal -f"
fi
START_SCRIPT

# Stop script
cat > /usr/local/bin/claude-terminal-stop << 'STOP_SCRIPT'
#!/bin/bash
echo "Stopping Claude Code Web Terminal..."
sudo systemctl stop claude-terminal
echo "✓ Stopped (sessions preserved until WSL restarts)"
STOP_SCRIPT

# Status script
cat > /usr/local/bin/claude-terminal-status << 'STATUS_SCRIPT'
#!/bin/bash
echo "=== Claude Code Web Terminal Status ==="
echo ""

if systemctl is-active --quiet claude-terminal; then
    echo "Service: ✓ Running"
else
    echo "Service: ✗ Stopped"
fi

if ss -tlnp 2>/dev/null | grep -q ':7681'; then
    echo "Port 7681: ✓ Listening"
else
    echo "Port 7681: ✗ Not listening"
fi

if command -v tailscale &> /dev/null; then
    TS_STATUS=$(tailscale status --json 2>/dev/null | grep -o '"BackendState":"[^"]*"' | cut -d'"' -f4)
    TS_IP=$(tailscale ip -4 2>/dev/null)
    echo "Tailscale: ${TS_STATUS:-Not running} ${TS_IP:+(IP: $TS_IP)}"
    
    if tailscale serve status 2>/dev/null | grep -q "7681"; then
        echo "Tailscale Serve: ✓ Active (HTTPS enabled)"
    else
        echo "Tailscale Serve: ✗ Not configured"
    fi
fi

echo ""
echo "=== Zellij Sessions ==="
zellij list-sessions 2>/dev/null || echo "No active sessions"
STATUS_SCRIPT

chmod +x "$USER_HOME/bin/claude-terminal-init"
chmod +x /usr/local/bin/claude-terminal-start
chmod +x /usr/local/bin/claude-terminal-stop
chmod +x /usr/local/bin/claude-terminal-status
chown "$USER_NAME:$USER_NAME" "$USER_HOME/bin/claude-terminal-init"

print_success "Helper scripts created"

# ============================================================================
# Setup passwordless sudo for service commands
# ============================================================================

print_status "Configuring passwordless sudo for service commands..."

cat > /etc/sudoers.d/claude-terminal << SUDOERS
$USER_NAME ALL=(ALL) NOPASSWD: /bin/systemctl start claude-terminal
$USER_NAME ALL=(ALL) NOPASSWD: /bin/systemctl stop claude-terminal
$USER_NAME ALL=(ALL) NOPASSWD: /bin/systemctl restart claude-terminal
$USER_NAME ALL=(ALL) NOPASSWD: /bin/systemctl status claude-terminal
$USER_NAME ALL=(ALL) NOPASSWD: /bin/kill
SUDOERS
chmod 440 /etc/sudoers.d/claude-terminal

print_success "Sudo configured"

# ============================================================================
# Create projects directory
# ============================================================================

if [ ! -d "$USER_HOME/$PROJECTS_DIR" ]; then
    mkdir -p "$USER_HOME/$PROJECTS_DIR"
    chown "$USER_NAME:$USER_NAME" "$USER_HOME/$PROJECTS_DIR"
fi

# ============================================================================
# Done
# ============================================================================

echo ""
echo "============================================================================"
print_success "Base installation complete!"
echo "============================================================================"
echo ""
echo "Next steps:"
echo ""
echo "  1. Install launcher tools:"
echo "     ${YELLOW}cd extras && sudo ./install-extras.sh${NC}"
echo ""
echo "  2. Start Tailscale (if not running):"
echo "     ${YELLOW}sudo tailscale up${NC}"
echo ""
echo "  3. Enable HTTPS remote access:"
echo "     ${YELLOW}tailscale serve --bg 7681${NC}"
echo ""
echo "  4. Start the terminal:"
echo "     ${YELLOW}claude-terminal-start${NC}"
echo ""
echo "  5. Open: http://localhost:7681"
echo ""
