#!/bin/bash
set -e

# ============================================================================
# Claude Code Web Terminal - Installation Script
# ============================================================================
# A mobile-friendly, persistent web terminal for Claude Code sessions
# Access from any browser — phone, tablet, or laptop
#
# Requirements:
#   - Ubuntu WSL (20.04, 22.04, or 24.04)
#   - Tailscale account (free at https://tailscale.com)
#   - sudo access
#
# Usage: sudo ./install.sh
# ============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
USER_NAME="${SUDO_USER:-$USER}"
USER_HOME=$(eval echo "~$USER_NAME")

# ============================================================================
# Configuration - Customize these if needed
# ============================================================================
TMUX_SESSION_NAME="claude"
TTYD_PORT="7681"
PROJECTS_DIR="projects"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status() { echo -e "${BLUE}[*]${NC} $1"; }
print_success() { echo -e "${GREEN}[✓]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[!]${NC} $1"; }
print_error() { echo -e "${RED}[✗]${NC} $1"; }

# ============================================================================
# Preflight Checks
# ============================================================================

print_status "Running preflight checks..."

if [[ $EUID -ne 0 ]]; then
    print_error "This script must be run with sudo"
    echo "Usage: sudo ./install.sh"
    exit 1
fi

if [ -z "$USER_NAME" ] || [ "$USER_NAME" = "root" ]; then
    print_error "Please run with sudo, not as root directly"
    echo "Usage: sudo ./install.sh"
    exit 1
fi

if ! grep -qi microsoft /proc/version 2>/dev/null; then
    print_warning "This doesn't appear to be WSL. Continuing anyway..."
fi

echo ""
echo "Installing for user: $USER_NAME"
echo "Home directory: $USER_HOME"
echo ""

# ============================================================================
# Install Dependencies
# ============================================================================

print_status "Updating package lists..."
apt-get update -qq

print_status "Installing ttyd..."
apt-get install -y -qq ttyd

print_status "Installing tmux..."
apt-get install -y -qq tmux
print_success "tmux installed: $(tmux -V)"

# ============================================================================
# Install/Check Tailscale
# ============================================================================

if ! command -v tailscale &> /dev/null; then
    print_status "Installing Tailscale..."
    curl -fsSL https://tailscale.com/install.sh | sh
    print_warning "Tailscale installed. Run 'sudo tailscale up' to authenticate."
else
    print_success "Tailscale already installed"
fi

# ============================================================================
# Create tmux Configuration
# ============================================================================

print_status "Creating tmux configuration..."

cat > "$USER_HOME/.tmux.conf" << 'TMUX_CONFIG'
# Claude Code Web Terminal - tmux Configuration
# Optimized for mobile/touch interaction via ttyd

# General settings
set -g default-terminal "xterm-256color"
set -g history-limit 50000
set -g mouse on
set -g base-index 1
setw -g pane-base-index 1
set -g renumber-windows on
set -g set-clipboard on

# Alt+1-9 to switch windows (like browser tabs)
bind -n M-1 select-window -t :1
bind -n M-2 select-window -t :2
bind -n M-3 select-window -t :3
bind -n M-4 select-window -t :4
bind -n M-5 select-window -t :5
bind -n M-6 select-window -t :6
bind -n M-7 select-window -t :7
bind -n M-8 select-window -t :8
bind -n M-9 select-window -t :9

# Status bar - claude theme colors
set -g status on
set -g status-position bottom
set -g status-style "bg=#1e1e1e,fg=#d4d4d4"
set -g status-left ""
set -g status-right ""

# Window status formatting (tab-like appearance)
setw -g window-status-format " #I:#W "
setw -g window-status-current-format " #I:#W "
setw -g window-status-current-style "bg=#569cd6,fg=#1e1e1e,bold"
setw -g window-status-style "bg=#2d2d2d,fg=#d4d4d4"
setw -g window-status-separator ""

# Reduce escape delay for responsive feel
set -sg escape-time 10
TMUX_CONFIG

chown "$USER_NAME:$USER_NAME" "$USER_HOME/.tmux.conf"
print_success "tmux configuration created"

# ============================================================================
# Install custom ttyd index.html
# ============================================================================

print_status "Installing custom ttyd frontend..."
mkdir -p /usr/local/share/claude-terminal
cp "$SCRIPT_DIR/html/index.html" /usr/local/share/claude-terminal/index.html
print_success "Custom ttyd frontend installed"

# ============================================================================
# Create bin directory
# ============================================================================

mkdir -p "$USER_HOME/bin"
chown "$USER_NAME:$USER_NAME" "$USER_HOME/bin"

# ============================================================================
# Create Systemd Service
# ============================================================================

print_status "Creating systemd service..."

cat > /etc/systemd/system/claude-terminal.service << SYSTEMD_SERVICE
[Unit]
Description=Claude Code Web Terminal (ttyd + tmux)
After=network.target

[Service]
Type=simple
User=$USER_NAME
Environment="HOME=$USER_HOME"
Environment="TERM=xterm-256color"
WorkingDirectory=$USER_HOME

ExecStart=/usr/bin/ttyd --writable --port $TTYD_PORT --index /usr/local/share/claude-terminal/index.html /usr/bin/tmux new-session -A -s $TMUX_SESSION_NAME

Restart=always
RestartSec=5

NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=read-only
ReadWritePaths=$USER_HOME
ReadWritePaths=/tmp
PrivateTmp=false

[Install]
WantedBy=multi-user.target
SYSTEMD_SERVICE

systemctl daemon-reload
systemctl enable claude-terminal
print_success "Systemd service created"

# ============================================================================
# Create Helper Scripts
# ============================================================================

print_status "Creating helper scripts..."

# Init script for clean startup
cat > "$USER_HOME/bin/claude-terminal-init" << 'INIT_SCRIPT'
#!/bin/bash
# Clean up stale sessions and start fresh

# Kill orphan ttyd processes (not from systemd)
for pid in $(pgrep -f "ttyd.*7681" 2>/dev/null); do
    if ! systemctl show claude-terminal --property=MainPID 2>/dev/null | grep -q "MainPID=$pid"; then
        sudo kill $pid 2>/dev/null
    fi
done

# Kill stale tmux session
tmux kill-session -t claude 2>/dev/null

# Restart the service
sudo systemctl restart claude-terminal

echo "Claude terminal ready at http://localhost:7681"
INIT_SCRIPT

# Start script
cat > /usr/local/bin/claude-terminal-start << 'START_SCRIPT'
#!/bin/bash
echo "Starting Claude Code Web Terminal..."
sudo systemctl start claude-terminal
sleep 2
if systemctl is-active --quiet claude-terminal; then
    echo "✓ Terminal running at http://localhost:7681"

    if command -v tailscale &> /dev/null; then
        TS_IP=$(tailscale ip -4 2>/dev/null)
        TS_HOSTNAME=$(tailscale status --json 2>/dev/null | grep -o '"Self":{[^}]*"DNSName":"[^"]*"' | grep -o '"DNSName":"[^"]*"' | cut -d'"' -f4 | sed 's/\.$//')
        if [[ -n "$TS_HOSTNAME" ]]; then
            echo "✓ Remote access: https://${TS_HOSTNAME}"
        fi
    fi
else
    echo "✗ Failed to start. Run: sudo journalctl -u claude-terminal -f"
fi
START_SCRIPT

# Stop script
cat > /usr/local/bin/claude-terminal-stop << 'STOP_SCRIPT'
#!/bin/bash
echo "Stopping Claude Code Web Terminal..."
sudo systemctl stop claude-terminal
echo "✓ Stopped (sessions preserved until WSL restarts)"
STOP_SCRIPT

# Status script
cat > /usr/local/bin/claude-terminal-status << 'STATUS_SCRIPT'
#!/bin/bash
echo "=== Claude Code Web Terminal Status ==="
echo ""

if systemctl is-active --quiet claude-terminal; then
    echo "Service: ✓ Running"
else
    echo "Service: ✗ Stopped"
fi

if ss -tlnp 2>/dev/null | grep -q ':7681'; then
    echo "Port 7681: ✓ Listening"
else
    echo "Port 7681: ✗ Not listening"
fi

if command -v tailscale &> /dev/null; then
    TS_STATUS=$(tailscale status --json 2>/dev/null | grep -o '"BackendState":"[^"]*"' | cut -d'"' -f4)
    TS_IP=$(tailscale ip -4 2>/dev/null)
    echo "Tailscale: ${TS_STATUS:-Not running} ${TS_IP:+(IP: $TS_IP)}"

    if tailscale serve status 2>/dev/null | grep -q "7681"; then
        echo "Tailscale Serve: ✓ Active (HTTPS enabled)"
    else
        echo "Tailscale Serve: ✗ Not configured"
    fi
fi

echo ""
echo "=== tmux Sessions ==="
tmux list-sessions 2>/dev/null || echo "No active sessions"
STATUS_SCRIPT

chmod +x "$USER_HOME/bin/claude-terminal-init"
chmod +x /usr/local/bin/claude-terminal-start
chmod +x /usr/local/bin/claude-terminal-stop
chmod +x /usr/local/bin/claude-terminal-status
chown "$USER_NAME:$USER_NAME" "$USER_HOME/bin/claude-terminal-init"

print_success "Helper scripts created"

# ============================================================================
# Setup passwordless sudo for service commands
# ============================================================================

print_status "Configuring passwordless sudo for service commands..."

cat > /etc/sudoers.d/claude-terminal << SUDOERS
$USER_NAME ALL=(ALL) NOPASSWD: /bin/systemctl start claude-terminal
$USER_NAME ALL=(ALL) NOPASSWD: /bin/systemctl stop claude-terminal
$USER_NAME ALL=(ALL) NOPASSWD: /bin/systemctl restart claude-terminal
$USER_NAME ALL=(ALL) NOPASSWD: /bin/systemctl status claude-terminal
$USER_NAME ALL=(ALL) NOPASSWD: /bin/systemctl start claude-terminal-healthcheck.timer
$USER_NAME ALL=(ALL) NOPASSWD: /bin/systemctl stop claude-terminal-healthcheck.timer
$USER_NAME ALL=(ALL) NOPASSWD: /bin/kill
SUDOERS
chmod 440 /etc/sudoers.d/claude-terminal

print_success "Sudo configured"

# ============================================================================
# Create projects directory
# ============================================================================

if [ ! -d "$USER_HOME/$PROJECTS_DIR" ]; then
    mkdir -p "$USER_HOME/$PROJECTS_DIR"
    chown "$USER_NAME:$USER_NAME" "$USER_HOME/$PROJECTS_DIR"
fi

# ============================================================================
# Create Health Check
# ============================================================================

print_status "Creating health check script and timer..."

cat > /usr/local/bin/claude-terminal-healthcheck << 'HEALTHCHECK'
#!/bin/bash
# Detects and recovers from tmux session issues and hung send-keys.

TMUX_SESSION="claude"
LOG_TAG="claude-healthcheck"

log() { logger -t "$LOG_TAG" "$1"; }

# Check if tmux server is running but session is missing
if tmux has-session -t "$TMUX_SESSION" 2>/dev/null; then
    : # Session is healthy
else
    # Session doesn't exist — check if the service thinks it's running
    if systemctl is-active --quiet claude-terminal; then
        log "tmux session '$TMUX_SESSION' is missing but service is active. Restarting service."
        systemctl restart claude-terminal
        log "Service restarted."
    fi
fi

# Kill orphaned 'tmux send-keys' processes running longer than 30s
while IFS= read -r pid; do
    [ -z "$pid" ] && continue
    elapsed=$(ps -o etimes= -p "$pid" 2>/dev/null | tr -d ' ')
    if [ -n "$elapsed" ] && [ "$elapsed" -gt 30 ]; then
        log "Killing hung tmux send-keys process (PID=$pid, elapsed=${elapsed}s)"
        kill "$pid" 2>/dev/null
    fi
done < <(pgrep -f "tmux send-keys" 2>/dev/null)
HEALTHCHECK

chmod +x /usr/local/bin/claude-terminal-healthcheck

cat > /etc/systemd/system/claude-terminal-healthcheck.service << 'HC_SERVICE'
[Unit]
Description=Claude Code Web Terminal Health Check

[Service]
Type=oneshot
ExecStart=/usr/local/bin/claude-terminal-healthcheck
HC_SERVICE

cat > /etc/systemd/system/claude-terminal-healthcheck.timer << 'HC_TIMER'
[Unit]
Description=Run Claude terminal health check every 30 seconds

[Timer]
OnBootSec=30s
OnUnitActiveSec=30s
AccuracySec=5s

[Install]
WantedBy=timers.target
HC_TIMER

systemctl daemon-reload
systemctl enable claude-terminal-healthcheck.timer
print_success "Health check timer installed"

# ============================================================================
# Done
# ============================================================================

echo ""
echo "============================================================================"
print_success "Base installation complete!"
echo "============================================================================"
echo ""
echo "Next steps:"
echo ""
echo "  1. Install launcher tools:"
echo "     ${YELLOW}cd extras && sudo ./install-extras.sh${NC}"
echo ""
echo "  2. Start Tailscale (if not running):"
echo "     ${YELLOW}sudo tailscale up${NC}"
echo ""
echo "  3. Enable HTTPS remote access:"
echo "     ${YELLOW}tailscale serve --bg 7681${NC}"
echo ""
echo "  4. Start the terminal:"
echo "     ${YELLOW}claude-terminal-start${NC}"
echo ""
echo "  5. Open: http://localhost:7681"
echo ""
