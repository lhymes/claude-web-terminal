#!/bin/bash
set -e

# ============================================================================
# Claude Code Launcher Tools - Installation
# ============================================================================
# Installs project launcher, aliases, and auto-start configuration
#
# Usage: sudo ./install-extras.sh
# ============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
USER_NAME="${SUDO_USER:-$USER}"
USER_HOME=$(eval echo "~$USER_NAME")

# Colors
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_status() { echo -e "${CYAN}[*]${NC} $1"; }
print_success() { echo -e "${GREEN}[✓]${NC} $1"; }

if [[ $EUID -ne 0 ]]; then
    echo "Run with sudo: sudo ./install-extras.sh"
    exit 1
fi

echo ""
echo "============================================================================"
echo "  Claude Code Launcher Tools"
echo "============================================================================"
echo ""

# Install fzf
if ! command -v fzf &> /dev/null; then
    print_status "Installing fzf..."
    apt-get update -qq && apt-get install -y fzf
fi

# Install launcher scripts
print_status "Installing launcher scripts..."

# Main project picker
cat > /usr/local/bin/claude-launcher << 'LAUNCHER'
#!/bin/bash
# Interactive project picker - launch multiple Claude Code sessions

PROJECTS_DIR="${CLAUDE_PROJECTS_DIR:-$HOME/projects}"
CLAUDE_CMD="${CLAUDE_CMD:-ccc}"

GREEN='\033[0;32m'
CYAN='\033[0;36m'
NC='\033[0m'

if [ -z "$ZELLIJ" ]; then
    echo -e "${CYAN}Starting Zellij session...${NC}"
    exec zellij attach claude --create
fi

if ! command -v fzf &> /dev/null; then
    echo "fzf not installed. Run: sudo apt install fzf"
    exit 1
fi

if [ ! -d "$PROJECTS_DIR" ]; then
    echo "Projects directory not found: $PROJECTS_DIR"
    echo "Create it with: mkdir -p $PROJECTS_DIR"
    exit 1
fi

projects=$(find "$PROJECTS_DIR" -maxdepth 1 -mindepth 1 -type d -printf '%f\n' | sort)

if [ -z "$projects" ]; then
    echo "No projects found in $PROJECTS_DIR"
    exit 1
fi

echo -e "${GREEN}Select projects (Tab=multi-select, Enter=launch):${NC}"
echo ""

selected=$(echo "$projects" | fzf --multi \
    --height=50% \
    --layout=reverse \
    --border \
    --prompt="Projects: " \
    --header="Tab=select, Enter=launch, Esc=cancel" \
    --preview="ls -la $PROJECTS_DIR/{}" \
    --preview-window=right:40%)

if [ -z "$selected" ]; then
    echo "No projects selected."
    exit 0
fi

echo ""
echo -e "${CYAN}Launching...${NC}"

for project in $selected; do
    echo -e "  ${GREEN}→${NC} $project"
    zellij action new-tab --name "$project"
    sleep 0.3
    zellij action write-chars "cd $PROJECTS_DIR/$project && $CLAUDE_CMD"
    zellij action write 10
    sleep 0.2
done

echo ""
echo -e "${GREEN}✓ Done! Switch tabs with Alt+1-9 or tap tab bar${NC}"
LAUNCHER

# Quick project launcher
cat > /usr/local/bin/clp << 'CLP'
#!/bin/bash
# Quick launch a single project

PROJECTS_DIR="${CLAUDE_PROJECTS_DIR:-$HOME/projects}"
CLAUDE_CMD="${CLAUDE_CMD:-ccc}"

if [ -z "$1" ]; then
    echo "Usage: clp <project-name>"
    echo ""
    echo "Available projects:"
    ls -1 "$PROJECTS_DIR" 2>/dev/null | sed 's/^/  /'
    exit 1
fi

PROJECT="$1"
PROJECT_PATH="$PROJECTS_DIR/$PROJECT"

if [ ! -d "$PROJECT_PATH" ]; then
    echo "Project not found: $PROJECT"
    echo ""
    echo "Similar projects:"
    ls -1 "$PROJECTS_DIR" | grep -i "$PROJECT" | sed 's/^/  /'
    exit 1
fi

if [ -z "$ZELLIJ" ]; then
    exec zellij attach claude --create
fi

zellij action new-tab --name "$PROJECT"
sleep 0.3
zellij action write-chars "cd $PROJECT_PATH && $CLAUDE_CMD"
zellij action write 10

echo "Launched: $PROJECT"
CLP

chmod +x /usr/local/bin/claude-launcher
chmod +x /usr/local/bin/clp

# Tab completion for clp
cat > /usr/local/share/clp-completion.bash << 'COMPLETION'
_clp_completions() {
    local projects_dir="${CLAUDE_PROJECTS_DIR:-$HOME/projects}"
    local cur="${COMP_WORDS[COMP_CWORD]}"
    if [ -d "$projects_dir" ]; then
        COMPREPLY=($(compgen -W "$(ls -1 "$projects_dir" 2>/dev/null)" -- "$cur"))
    fi
}
complete -F _clp_completions clp
COMPLETION

print_success "Launcher scripts installed"

# Update bashrc
print_status "Updating ~/.bashrc..."

BASHRC="$USER_HOME/.bashrc"
MARKER="# === Claude Code Web Terminal ==="

# Remove old config if exists
sed -i "/$MARKER/,/# === End Claude Code ===/d" "$BASHRC" 2>/dev/null

cat >> "$BASHRC" << 'BASHRC_ADDITIONS'

# === Claude Code Web Terminal ===

# Configuration - customize these:
export CLAUDE_PROJECTS_DIR="$HOME/projects"
export CLAUDE_CMD="ccc"  # Your Claude command (claude, ccc, etc.)

# Auto-start service when terminal opens
if ! systemctl is-active --quiet claude-terminal 2>/dev/null; then
    ~/bin/claude-terminal-init 2>/dev/null &
fi

# Aliases
alias cl='claude-launcher'
alias clp='clp'
alias cls='claude-terminal-status'
alias zj='zellij attach claude --create'

# Tab completion
if [ -f /usr/local/share/clp-completion.bash ]; then
    source /usr/local/share/clp-completion.bash
fi

# Create new project and launch
cnew() {
    if [ -z "$1" ]; then
        echo "Usage: cnew <project-name>"
        return 1
    fi
    mkdir -p "$CLAUDE_PROJECTS_DIR/$1"
    clp "$1"
}

# === End Claude Code ===
BASHRC_ADDITIONS

chown "$USER_NAME:$USER_NAME" "$BASHRC"
print_success "~/.bashrc updated"

echo ""
echo "============================================================================"
print_success "Installation complete!"
echo "============================================================================"
echo ""
echo "Commands (restart terminal or run 'source ~/.bashrc'):"
echo ""
echo "  ${GREEN}cl${NC}                  Pick projects to launch (multi-select)"
echo "  ${GREEN}clp ProjectName${NC}    Quick-launch one project"
echo "  ${GREEN}cnew ProjectName${NC}   Create new project + launch"
echo "  ${GREEN}cls${NC}                 Check service status"
echo "  ${GREEN}zj${NC}                  Attach to Zellij manually"
echo ""
echo "Daily workflow:"
echo "  1. Open browser: http://localhost:7681"
echo "  2. Type: cl"
echo "  3. Select projects, press Enter"
echo "  4. Switch tabs: Alt+1-9 or tap tab bar"
echo ""
echo "Configuration (edit in ~/.bashrc if needed):"
echo "  CLAUDE_PROJECTS_DIR  - Where your projects live"
echo "  CLAUDE_CMD           - Command to start Claude"
echo ""
